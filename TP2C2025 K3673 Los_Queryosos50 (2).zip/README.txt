Curso: K3673
Numero de Grupo: 50
Integrantes: 
Paredes Carvajal, Juan Sebastian - 1687050
Chalco Chuquimia, Aylen Maricel - 1677780
Baptista, Matias - 1563592
Herrera, Herrera - 1677240
E-mail Responsable: jparedescarvajal@frba.utn.edu.ar